# Nordic Dispatch – FiveM RP

## Öppna lokalt
1. Packa upp ZIP-filen.
2. Öppna `index.html` i Chrome, Edge eller Firefox.
3. Logga in med valfritt operatörsnamn och lösenordet `dispatch123`.

## Publicera gratis med GitHub Pages
1. Logga in på https://github.com och skapa ett nytt repository, t.ex. `nordic-dispatch`.
2. Välj **Add file → Upload files** och ladda upp `index.html` (eller ladda upp hela innehållet i ZIP-filen).
3. Öppna repositoryts **Settings → Pages**.
4. Under **Build and deployment**, välj **Deploy from a branch**.
5. Välj branch `main` och mapp `/ (root)`, tryck **Save**.
6. Vänta någon minut. GitHub visar länken till webbplatsen på samma Pages-sida.

## Funktioner
- Larmcentral: skapa, ändra, prioritera, tilldela enhet och avsluta larm.
- Polisradio: simulerad textlogg och snabbstatus.
- Schematisk GPS-vy (inte kopplad till riktig GTA-karta).
- Enheter/patruller med status.
- Karaktärer, fordonsregister, RP-bankkonton och löneutbetalningar.
- Lokal lagring i webbläsaren samt JSON-export/import av backup.

## Viktiga begränsningar
Detta är en fungerande fristående prototyp, inte en FiveM-resource. Inloggningen är bara en demo, och data lagras lokalt i den webbläsare där sidan öppnas. Andra spelare kan inte dela data mellan sig. GitHub Pages kan bara hosta den statiska webbappen; riktig säker inloggning, gemensam databas, realtidsradio, spelpositioner och koppling till FiveM kräver en backend och ett separat FiveM-resource (t.ex. Lua/JS med serverevents).
