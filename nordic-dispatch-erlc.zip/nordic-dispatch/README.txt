NORDIC DISPATCH – DEMO + ER:LC API
==================================

Frontend
--------
- index.html är webbappen. Den kan publiceras på GitHub Pages.
- GitHub Pages kör inte Node.js-backend; backend-mappen måste publiceras separat på en Node.js-tjänst med HTTPS.

ER:LC API-anslutning
--------------------
1. Din ER:LC private server måste ha köpt ER:LC API Pack.
2. I spelet: öppna private server Settings och kopiera/generera Server API Key under ER:LC API.
3. Publicera mappen backend på en Node.js-host (Node.js 20 eller nyare) med HTTPS. Startkommando: npm start (eller node server.js).
4. Sätt miljövariabeln DASHBOARD_TOKEN till en lång, slumpmässig hemlighet i hosting-tjänstens Environment Variables. Sätt också ALLOWED_ORIGIN till din GitHub Pages-origin, exempelvis https://DITT-ANVÄNDARNAMN.github.io. Om sidan ligger i ett repository-underkatalogsnamn ingår inte den sökvägen i Origin.
5. Öppna Nordic Dispatch → ER:LC API. Skriv backendens HTTPS-URL, samma DASHBOARD_TOKEN som Backend access token och klistra in Server API Key. Tryck Anslut.
6. Anslutningen valideras mot GET https://api.erlc.gg/v2/server med headern server-key. Knappen Uppdatera serverdata hämtar ny status.

SÄKERHET
--------
- Klistra aldrig in API-nyckeln i index.html, i GitHub-kod, i README eller i en skärmbild.
- Nyckeln skickas via HTTPS till backend och lagras endast i backendens minne. Den raderas när backend startas om och måste då anges igen.
- Backendens nuvarande version är en grundläggande prototyp för en enskild privat dashboard. Backend kräver DASHBOARD_TOKEN. Håll den hemlig och dela den endast med betrodda operatörer.
- Den här kopplingen läser serverstatus. Den skickar inte fjärrkommandon och är inte en FiveM-resource.
- Om API-nyckeln råkar publiceras, rotera/regenerera den direkt i ER:LC.

Demo-inloggning till själva frontend
-----------------------------------
Valfritt operatörsnamn, lösenord: dispatch123. Detta är en lokal demo-inloggning och inte säker autentisering.
