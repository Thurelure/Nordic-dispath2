const http = require('node:http');
const { URL } = require('node:url');

const PORT = Number(process.env.PORT || 3000);
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '*';
const DASHBOARD_TOKEN = process.env.DASHBOARD_TOKEN || '';
let serverKey = null; // Intentionally memory-only; never write the ER:LC key to disk.

function send(res, status, body) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Dashboard-Token',
    'Cache-Control': 'no-store'
  });
  res.end(JSON.stringify(body));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => { body += chunk; if (body.length > 10000) reject(new Error('Requesten är för stor')); });
    req.on('end', () => { try { resolve(JSON.parse(body || '{}')); } catch { reject(new Error('Ogiltig JSON')); } });
    req.on('error', reject);
  });
}
async function fetchServer(key) {
  const response = await fetch('https://api.erlc.gg/v2/server', {
    method: 'GET', headers: { 'server-key': key, 'Accept': 'application/json' }, signal: AbortSignal.timeout(12000)
  });
  const raw = await response.text();
  let data; try { data = JSON.parse(raw); } catch { data = { message: raw.slice(0, 500) }; }
  if (!response.ok) {
    const error = new Error(data.message || data.error || `ER:LC API svarade med HTTP ${response.status}`);
    error.status = response.status;
    throw error;
  }
  return data;
}
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (req.method === 'OPTIONS') return send(res, 204, {});
  if (url.pathname === '/health' && req.method === 'GET') return send(res, 200, { ok: true, service: 'Nordic Dispatch ER:LC backend' });
  if (!DASHBOARD_TOKEN) return send(res, 503, { error: 'Backend saknar DASHBOARD_TOKEN. Konfigurera en hemlig token i hosting-tjänstens environment variables.' });
  if (req.headers['x-dashboard-token'] !== DASHBOARD_TOKEN) return send(res, 401, { error: 'Fel backend access token.' });
  try {
    if (url.pathname === '/api/erlc/connect' && req.method === 'POST') {
      const body = await readBody(req);
      const candidate = String(body.serverKey || '').trim();
      if (!candidate || candidate.length > 500) return send(res, 400, { error: 'Ange en giltig ER:LC Server API Key.' });
      const serverData = await fetchServer(candidate); // Validate before keeping the key.
      serverKey = candidate;
      return send(res, 200, { connected: true, server: serverData });
    }
    if (url.pathname === '/api/erlc/status' && req.method === 'GET') {
      if (!serverKey) return send(res, 409, { error: 'Ingen ER:LC-nyckel är ansluten. Anslut igen från Nordic Dispatch.' });
      const serverData = await fetchServer(serverKey);
      return send(res, 200, { connected: true, server: serverData });
    }
    if (url.pathname === '/api/erlc/disconnect' && req.method === 'POST') {
      serverKey = null;
      return send(res, 200, { connected: false });
    }
    return send(res, 404, { error: 'Endpoint hittades inte.' });
  } catch (err) {
    const status = err.status || (err.name === 'TimeoutError' ? 504 : 502);
    return send(res, status, { error: err.message || 'Fel vid kontakt med ER:LC API.' });
  }
});
server.listen(PORT, '0.0.0.0', () => console.log(`Nordic Dispatch ER:LC backend listening on ${PORT}`));
